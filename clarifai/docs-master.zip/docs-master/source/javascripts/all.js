//= require_tree ./lib
//= require_tree ./app
