//= require_tree ./lib
//= require_tree ./app
//= stub ./app/search.js
//= stub ./lib/lunr.js
